package nutzerberechtigungen;

public class DAO {

	public String getAdminPWD() {
		return "1234";
	}
	public String getAdminBName() {
		return "admin";
	}
	
	public String getUserBName() {
		return "user";
	}
	public String getUserPWD() {
		return "1234";
	}
}
